package kp.propertypattern;

public interface CloneableProperties<N, V> extends Properties<N, V>, Cloneable {

    CloneableProperties<N, V> clone();
}
