package kp.propertypattern;

import java.util.Set;

public interface FilterableProperties<N, V> extends Properties<N, V> {

    Set<N> filter(N filter);

}
