package kp.propertypattern;

import java.util.Set;
import static kp.propertypattern.HashMapProperties.PARENT;


public final class main {

    public static void main(final String[] args) {


    /*
     * create a parent properties object for Lionel Messi
     */
        FilterableProperties parent = new HashMapProperties();
        parent.put("firstname", "Lionel");
        parent.put("lastname", "Messi");
        parent.put("speed", "fast");
        parent.put("header", "bad");
        parent.put("dribbling", "great");

    /*
     * create a properties object which inherits the values of Lionel Messi
     */
        HashMapProperties properties = new HashMapProperties();
        properties.put(PARENT, parent);

    /*
     * clone the properties object and override some properties
     */
        HashMapProperties clone = properties.clone();
        clone.put("firstname", "Leon");
        clone.put("lastname", "Goretzka");
        clone.put("header", "good");


        System.out.println("***************************************************************");
        System.out.println("Property values for the parent property list -- Lionel Messi --");
        Set<String> props = properties.filter(".*");
        for (String prop : props) {
            System.out.println(properties.get(prop));
        }

        System.out.println("\n\n***************************************************************");
        System.out.println("Property values for the clone property list -- Leon Goretzka --");
        Set<String> cProps = clone.filter(".*");
        for (String cProp : cProps) {
            System.out.println(clone.get(cProp));
        }


    }
}

